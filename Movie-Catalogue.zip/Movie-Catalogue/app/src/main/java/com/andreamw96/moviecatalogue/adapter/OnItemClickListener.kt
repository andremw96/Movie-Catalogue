package com.andreamw96.moviecatalogue.adapter

interface OnItemClickListener {
    fun onItemClicked(position: Int)
}
